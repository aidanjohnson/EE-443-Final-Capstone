SVM Training and Feature Extraction

- main.py

* This python code processes the audio files to extract the MFCCs
and spectral moments, writes them to a dat files which is used to train
and test the SVM in SVMTorch (a C++ program for SVM training and test).
Much of the code here parses through the training and testing data to
find the files which are of a single instrument and the instruments we
are interested in.

- main_17feats.py
- featureplan.txt
- results_17feats.txt

* Results and python code for best results detailed in Tables 1 and 2.

- divide_data.sh


* Python script for rebuilding the dataset in Unix Terminal.


GMM Feature Extraction and Training

- gmm_training.m

* MATLAB code that processes audio files to extract features and trains the
GMM using the built in MATLAB function.

- GetCoefficient.m
- NormalizationFactor.m
- GetFilterParameter.m
- GetMagnitudeFactor.m
- GetCenterFrequency.m

* MATLAB code that computes the MFCCs

- GetShapeStatistics.m

* MATLAB code that computes the MFCCs

- gmm_write.m

* Writes GMM model parameters into text files which are formatted so they
can be copied into the LCDK source code.


LCDK C Source Code

- main.c
- ISRs.c
- gmm.c
- gmm.h
- libmfcc.c
- libmfcc.h